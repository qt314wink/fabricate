/// <reference lib="webworker" />
import { tessellatePlate, meshToAsciiStl, type PlateSpec } from "./tessellate";

export type TessRequest = { id: number; spec: PlateSpec; name?: string };
export type TessResponse = { id: number; stl: string; triangles: number; ms: number };

self.onmessage = (e: MessageEvent<TessRequest>) => {
  const t0 = performance.now();
  const mesh = tessellatePlate(e.data.spec);
  const stl = meshToAsciiStl(mesh, e.data.name ?? "part");
  const res: TessResponse = {
    id: e.data.id,
    stl,
    triangles: mesh.indices.length / 3,
    ms: performance.now() - t0,
  };
  (self as DedicatedWorkerGlobalScope).postMessage(res);
};
