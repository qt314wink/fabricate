import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { holeCenters, holeRadiusAt, MAX_HOLES } from "../../geometry/bracket";
import { visibleCount } from "../../geometry/toolpath";
import { gcodeToolpath } from "../../geometry/gcode";
import { createGestureSession } from "../../interact/gestures";
import { tessellatePlate } from "../../geometry/tessellate";
import { useBracketStore } from "./store";
import { bracketTable } from "./step";

const EMISSIVE = new THREE.Color("#7cdb7a");

/** B14 — on-screen mesh is the same tessellator as STL, not a scaled box. */
export function BracketMesh() {
  const mesh = useRef<THREE.Mesh>(null);
  const mat = useRef<THREE.MeshStandardMaterial>(null);
  const geom = useMemo(() => new THREE.BufferGeometry(), []);
  const pathGeom = useMemo(() => new THREE.BufferGeometry(), []);
  const lastKey = useRef("");
  const pathPts = useRef<{ x: number; y: number; z: number }[]>([]);
  const gest = useRef(
    createGestureSession({
      rotate: (dv) =>
        useBracketStore.setState((s) => ({
          targets: { ...s.targets, orbitImpulse: (s.targets.orbitImpulse ?? 0) + dv },
        })),
      scale: (f) => {
        const w = useBracketStore.getState().targets.width;
        useBracketStore.getState().setParam("width", w * f);
      },
      highlight: () =>
        useBracketStore.setState((s) => ({ targets: { ...s.targets, emissive: 1 } })),
    }),
  );


  useFrame(() => {
    const d = bracketTable.values();
    if (mesh.current) mesh.current.rotation.y = d.orbit ?? 0;
    if (mat.current) {
      mat.current.emissive.copy(EMISSIVE);
      mat.current.emissiveIntensity = d.emissive ?? 0;
    }
    const key = `${d.width}|${d.height}|${d.thickness}|${d.fillet}|${d.holeCount}|${d.holeRadius}`;
    if (key !== lastKey.current) {
      lastKey.current = key;
      const holes = Array.from({ length: MAX_HOLES }, (_, i) => {
        const [x, y] = holeCenters(d as never)[i];
        return { x, y, r: holeRadiusAt(d as never, i) };
      });
      const tri = tessellatePlate({
        width: d.width,
        height: d.height,
        thickness: d.thickness,
        fillet: d.fillet ?? 0,
        holes,
        pitch: 3,
      });
      geom.setAttribute("position", new THREE.BufferAttribute(tri.positions, 3));
      geom.setIndex(new THREE.BufferAttribute(tri.indices, 1));
      geom.computeVertexNormals();
      pathPts.current = gcodeToolpath(d as never);
    }
    if ((d.pathProgress ?? 0) > 0) {
      const pts = pathPts.current;
      const n = visibleCount(pts, d.pathProgress ?? 0);
      const arr = new Float32Array(Math.max(n, 1) * 3);
      for (let i = 0; i < n; i++) {
        arr[i * 3] = pts[i].x;
        arr[i * 3 + 1] = pts[i].z + 0.4;
        arr[i * 3 + 2] = pts[i].y;
      }
      pathGeom.setAttribute("position", new THREE.BufferAttribute(arr, 3));
      pathGeom.setDrawRange(0, n);
    }
  });

  return (
    <group>
      <mesh
        ref={mesh}
        geometry={geom}
        onPointerDown={(e) => {
          useBracketStore.getState().dispatch({ type: "POINTER_DOWN_MESH" });
          gest.current.pointerDown(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (e.buttons) gest.current.pointerMove(e.clientX, e.clientY);
        }}
        onPointerUp={() => {
          useBracketStore.getState().dispatch({ type: "POINTER_UP" });
          gest.current.pointerUp();
        }}
        onClick={() => gest.current.tap()}
      >
        <meshStandardMaterial ref={mat} color="#8a9098" metalness={0.35} roughness={0.4} side={THREE.DoubleSide} />
      </mesh>
      <line>
        <primitive object={pathGeom} attach="geometry" />
        <lineBasicMaterial color="#7cdb7a" />
      </line>
    </group>
  );
}
